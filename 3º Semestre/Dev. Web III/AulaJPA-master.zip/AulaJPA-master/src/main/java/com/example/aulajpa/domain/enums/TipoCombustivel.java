package com.example.aulajpa.domain.enums;

public enum TipoCombustivel {

    GASOLINA,
    ALCOOL,
    DIESEL,
    FLEX,
    ELETRICO;
}
