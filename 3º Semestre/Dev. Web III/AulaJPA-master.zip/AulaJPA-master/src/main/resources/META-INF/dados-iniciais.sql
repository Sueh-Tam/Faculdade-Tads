insert into veiculo (codigo, fabricante, modelo, ano_fabricacao, ano_modelo, valor) values (1, 'Fiat', 'Toro', 2020, 2020, 107000);

insert into veiculo (codigo, fabricante, modelo, ano_fabricacao, ano_modelo, valor) values (2, 'Ford', 'Fiesta', 2019, 2019, 42000);

insert into veiculo (codigo, fabricante, modelo, ano_fabricacao, ano_modelo, valor) values (3, 'Renault', 'Clio', 2013, 2013, 20000);