package br.edu.ifpr.persistproject.repository;

public class DepartmentRepository {
}
