public class ExceptionsCsvFile extends Exception{
    
}
