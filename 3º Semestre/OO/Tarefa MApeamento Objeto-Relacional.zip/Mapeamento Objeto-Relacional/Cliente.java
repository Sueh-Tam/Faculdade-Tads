public class Cliente {
    private int codigo;
    private String nome;
    private String endereco;
    private String data_aniversaio;
    private String data_atualizacao;
    private String data_insercao;
    
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    public String getData_aniversaio() {
        return data_aniversaio;
    }
    public void setData_aniversaio(String data_aniversaio) {
        this.data_aniversaio = data_aniversaio;
    }
    
    public String getData_atualizacao() {
        return data_atualizacao;
    }
    public void setData_atualizacao(String data_atualizacao) {
        this.data_atualizacao = data_atualizacao;
    }
    public void setData_insercao(String data_insercao) {
        this.data_insercao = data_insercao;
    }
    public String getData_insercao() {
        return data_insercao;
    }
    
    
    
}
